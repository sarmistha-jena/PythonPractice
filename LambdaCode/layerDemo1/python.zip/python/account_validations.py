def validateAcct(AcctNo):
    if len(AcctNo) == 10:
        return 'True'
    else:
        return 'False'